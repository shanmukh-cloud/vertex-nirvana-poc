#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""

Strip type hints from Python code files.

"""

from __future__ import print_function, division, absolute_import

# Just import all for now.
from .strip_hints_main import *
from .token_list import *

